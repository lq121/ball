#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBScheduleBiSaiVC : UIViewController
- (void)getBiSaiData;
@property(nonatomic,assign)BOOL hasSelect;
@end

NS_ASSUME_NONNULL_END
