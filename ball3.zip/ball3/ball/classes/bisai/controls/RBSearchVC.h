#import <UIKit/UIKit.h>


NS_ASSUME_NONNULL_BEGIN

@interface RBSearchVC : UIViewController
@property (nonatomic, strong) NSArray *tagsArray;
@end

NS_ASSUME_NONNULL_END
