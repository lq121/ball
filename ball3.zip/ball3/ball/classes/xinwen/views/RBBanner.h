#import <UIKit/UIKit.h>
#import "RBBannerModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBBanner : UIView
@property(nonatomic,strong)RBBannerModel *bannerModel;
@end

NS_ASSUME_NONNULL_END
