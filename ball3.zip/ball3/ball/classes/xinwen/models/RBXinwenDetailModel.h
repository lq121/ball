#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBXinwenDetailModel : NSObject
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *img;
@property (nonatomic, assign) int status;
@end

NS_ASSUME_NONNULL_END
