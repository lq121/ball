#import "RBBannerModel.h"

@implementation RBBannerModel

@end
