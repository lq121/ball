#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBHuaTiHuiFuModel : NSObject
@property (nonatomic, copy) NSString *Hfavatar;
@property (nonatomic, copy) NSString *Hfeduid;
@property (nonatomic, copy) NSString *Hfid;
@property (nonatomic, copy) NSString *Hfname;
@property (nonatomic, copy) NSString *Hftxt;
@property (nonatomic, copy) NSString *Hfuid;
@property (nonatomic, copy) NSString *LzUid;
@property (nonatomic, strong) NSArray *secondArr;
@property (nonatomic, assign) int Hflv;
@property (nonatomic, assign) int Hftime;
@property (nonatomic, assign) int Hfvip;
@property (nonatomic, assign) int Htid;
@property (nonatomic, assign) int Id;
@property (nonatomic, assign) int Zan;
@property (nonatomic, assign) int Zannum;
@property (nonatomic, assign) int Zant;
@property (nonatomic, assign) int index;
@property (nonatomic, assign) int canRep;
@property(nonatomic,assign)int type;
@property(nonatomic,assign)int Comnum;
@end

NS_ASSUME_NONNULL_END
