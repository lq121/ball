#import "RBXinwenDetailModel.h"

@implementation RBXinwenDetailModel

@end
