#import "RBHuaTiModel.h"

@implementation RBHuaTiModel

@end
