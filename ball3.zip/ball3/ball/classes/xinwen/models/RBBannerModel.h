#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBBannerModel : NSObject
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, assign) int number;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *desTitle;
@end

NS_ASSUME_NONNULL_END
