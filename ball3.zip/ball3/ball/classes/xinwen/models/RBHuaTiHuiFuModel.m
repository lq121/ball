#import "RBHuaTiHuiFuModel.h"

@implementation RBHuaTiHuiFuModel

@end
