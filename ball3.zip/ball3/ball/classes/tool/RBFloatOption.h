#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBFloatOption : NSObject
+ (BOOL)judgeDivisibleWithFirstNumber:(CGFloat)firstNumber andSecondNumber:(CGFloat)secondNumber;
@end

NS_ASSUME_NONNULL_END
