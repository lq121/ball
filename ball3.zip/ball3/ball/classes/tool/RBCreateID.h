#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBCreateID : NSObject
+ (NSString *)createMyIDInKeyCH;

+ (void)deleteKey;
@end

NS_ASSUME_NONNULL_END
