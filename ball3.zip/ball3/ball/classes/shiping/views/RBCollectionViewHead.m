#import "RBCollectionViewHead.h"

@implementation RBCollectionViewHead


@end
