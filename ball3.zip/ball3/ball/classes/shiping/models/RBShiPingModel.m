#import "RBShiPingModel.h"

@implementation RBShiPingModel

@end
