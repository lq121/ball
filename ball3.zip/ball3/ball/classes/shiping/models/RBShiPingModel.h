#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBShiPingModel : NSObject
@property (nonatomic, copy) NSString *Titleimg;
@property (nonatomic, copy) NSString *Title;
@property (nonatomic, copy) NSString *Url;
@property (nonatomic, assign) int Heng;
@property (nonatomic, assign) int Id;
@property (nonatomic, assign) int Comment;
@property (nonatomic, copy) NSString *Uid;
@end

NS_ASSUME_NONNULL_END
