#import "RBBaseVC.h"
#import "RBShiPingModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBHengShiPingVC : RBBaseVC
@property(nonatomic,strong)RBShiPingModel *shiPingModel;
@end

NS_ASSUME_NONNULL_END
