
#import <UIKit/UIKit.h>
#import "RBBaseVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBShiPingVC : RBBaseVC

@end

NS_ASSUME_NONNULL_END
