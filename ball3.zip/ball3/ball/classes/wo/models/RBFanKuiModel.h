#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBFanKuiModel : NSObject
@property (nonatomic, copy) NSString *Contact;
@property (nonatomic, assign) int Createt;
@property (nonatomic, assign) int Id;
@property (nonatomic, copy) NSString *Img;
@property (nonatomic, copy) NSString *Reply;
@property (nonatomic, assign) int Style;
@property (nonatomic, copy) NSString *Title;
@property (nonatomic, copy) NSString *Txt;
@property (nonatomic, copy) NSString *Uid;
@end

NS_ASSUME_NONNULL_END
