#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBXiaoXiModel : NSObject
@property (nonatomic, assign) int t;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *txt;
@property (nonatomic, assign) int type;
@property(nonatomic,assign)int Id;
@end

NS_ASSUME_NONNULL_END
