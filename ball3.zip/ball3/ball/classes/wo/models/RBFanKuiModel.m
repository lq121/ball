#import "RBFanKuiModel.h"

@implementation RBFanKuiModel

@end
