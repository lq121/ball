#import "RBDaoJuModel.h"

@implementation RBDaoJuModel
;
@end
