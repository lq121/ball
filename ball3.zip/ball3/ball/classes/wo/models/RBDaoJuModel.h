#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBDaoJuModel : NSObject
@property (nonatomic, copy) NSString *Anchorname;
@property (nonatomic, assign) int Commission;
@property (nonatomic, assign) int Cost;
@property (nonatomic, copy) NSString *CreateT;
@property (nonatomic, copy) NSString *Dealno;
@property (nonatomic, copy) NSString *Game;
@property (nonatomic, copy) NSString *Id;
@property (nonatomic, assign) int Propid;
@property (nonatomic, assign) int State;
@property (nonatomic, copy) NSString *Username;
@end

NS_ASSUME_NONNULL_END
