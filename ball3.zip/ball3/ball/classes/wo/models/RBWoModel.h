#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBWoModel : NSObject
@property (copy, nonatomic) NSString *image;
@property (copy, nonatomic) NSString *tip;
@property(nonatomic,copy)NSString *Usedyqcode;
@end

NS_ASSUME_NONNULL_END
