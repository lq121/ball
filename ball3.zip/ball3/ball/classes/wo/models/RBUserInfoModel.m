#import "RBUserInfoModel.h"

@implementation RBUserInfoModel

@end
