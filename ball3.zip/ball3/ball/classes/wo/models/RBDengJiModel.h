#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBDengJiModel : NSObject
@property (copy, nonatomic) NSString *icon;
@property (copy, nonatomic) NSString *title;
@property (copy, nonatomic) NSString *des;
@property (assign, nonatomic, readwrite) Boolean isOther;
@end

NS_ASSUME_NONNULL_END
