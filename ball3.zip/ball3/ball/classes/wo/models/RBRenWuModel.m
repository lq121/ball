#import "RBRenWuModel.h"

@implementation RBRenWuModel

@end
