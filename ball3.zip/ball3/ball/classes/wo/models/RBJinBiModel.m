#import "RBJinBiModel.h"

@implementation RBJinBiModel

@end
