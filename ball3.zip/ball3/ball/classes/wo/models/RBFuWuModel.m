#import "RBFuWuModel.h"

@implementation RBFuWuModel

@end
