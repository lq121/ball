#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBFuWuModel : NSObject
@property (nonatomic, assign) int Cost;
@property (nonatomic, assign) int Costtype;
@property (nonatomic, copy) NSString *CreateT;
@property (nonatomic, copy) NSString *Id;
@property (nonatomic, copy) NSString *Dealno;
@property (nonatomic, copy) NSString *Mark;
@property (nonatomic, copy) NSString *Username;
@property (nonatomic, assign) int State;
@property(nonatomic,assign)int Money;
@end

NS_ASSUME_NONNULL_END
