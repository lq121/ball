#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBBangZhuDesVC : UIViewController
@property (nonatomic, assign) int selectItem;
@end

NS_ASSUME_NONNULL_END
