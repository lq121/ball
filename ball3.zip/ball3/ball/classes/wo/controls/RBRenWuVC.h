#import <UIKit/UIKit.h>
#import "RBBaseTabVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBRenWuVC : RBBaseTabVC
@property(nonatomic,copy)NSString *Yqcode;
@property (nonatomic, assign) int vip;
@property (nonatomic, assign) int vipst;
@property(nonatomic,strong)NSDictionary *dict;
@end

NS_ASSUME_NONNULL_END
