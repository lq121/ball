#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBXiuGaiPwdVC : UIViewController
@property (nonatomic, copy) NSString *phone;
@end

NS_ASSUME_NONNULL_END
