#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBYQMVC : UIViewController
@property(nonatomic,copy)NSString *Yqcode;
@property(nonatomic,copy)NSString *Usedyqcode;
@end

NS_ASSUME_NONNULL_END
