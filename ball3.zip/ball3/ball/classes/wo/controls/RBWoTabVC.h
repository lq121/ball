#import "RBBaseTabVC.h"
#import "RBHudongHeadView.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBWoTabVC : RBBaseTabVC
- (void)getUserInfo;
@end

NS_ASSUME_NONNULL_END
