#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBXiuGaiNiChengVC : UIViewController
@property (nonatomic, copy) NSString *nickName;

@end

NS_ASSUME_NONNULL_END
