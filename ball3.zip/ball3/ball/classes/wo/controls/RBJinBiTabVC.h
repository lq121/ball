#import "RBBaseTabVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBJinBiTabVC : RBBaseTabVC

@end

NS_ASSUME_NONNULL_END
