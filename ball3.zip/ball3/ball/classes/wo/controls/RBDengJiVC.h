#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RBDengJiVC : UIViewController
@property (nonatomic, assign) int lv;
@property (nonatomic, assign) int exp;
@end

NS_ASSUME_NONNULL_END
