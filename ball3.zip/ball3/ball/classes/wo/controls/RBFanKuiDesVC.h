#import <UIKit/UIKit.h>
#import "RBFanKuiModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBFanKuiDesVC : UIViewController
@property(nonatomic,strong)RBFanKuiModel *fanKuiModel;
@end

NS_ASSUME_NONNULL_END
