#import "RBBaseTabVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBPredictListTabVC : RBBaseTabVC

@end

NS_ASSUME_NONNULL_END
