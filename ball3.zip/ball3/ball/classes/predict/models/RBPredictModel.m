#import "RBPredictModel.h"

@implementation RBPredictModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{ @"rangqiuArr": @"rangqiu"};
}
@end
