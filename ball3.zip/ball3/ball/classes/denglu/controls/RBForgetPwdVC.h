#import "RBBaseVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBForgetPwdVC : RBBaseVC
@property (nonatomic, copy) NSString *phone;
@end

NS_ASSUME_NONNULL_END
